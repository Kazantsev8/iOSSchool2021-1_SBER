//
//  ViewController.swift
//  14thLessionOnLession
//
//  Created by Иван Казанцев on 24.05.2021.
//

import UIKit

class ViewController: UIViewController {
    
    var tableView = UITableView()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        let customCell = UINib(nibName: "CustomCell", bundle: nil)
        tableView.register(CustomCell.self, forCellReuseIdentifier: "CustomCell")
    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return CustomCell()
    }
    
}


